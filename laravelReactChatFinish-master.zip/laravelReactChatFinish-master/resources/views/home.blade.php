@extends('layouts.app')

@section('content')
<div class="container" style="padding: 0; margin-top: -1.5em; margin-left: 0;">
    <div id="test" style="padding: 0; margin: 0;"></div> 
</div>

@endsection
